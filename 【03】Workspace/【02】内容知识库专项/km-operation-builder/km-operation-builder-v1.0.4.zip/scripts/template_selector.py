# -*- coding: utf-8 -*-
"""模板选择器模块 - 根据知识库信息推荐合适的操作模板"""

TEMPLATE_INFO = {
    "basic": {
        "id": "basic",
        "name": "基础版",
        "description": "浏览、读取、总结知识库内容",
        "capabilities": ["browse", "read", "summarize"],
        "required_permissions": [],
        "suitable_for": ["查询信息", "了解知识库结构", "快速概览"]
    },
    "operation": {
        "id": "operation",
        "name": "运营版",
        "description": "基础功能 + 统计、分析、回复生成",
        "capabilities": ["browse", "read", "summarize", "statistics", "analysis", "reply_generation"],
        "required_permissions": ["read"],
        "suitable_for": ["数据统计", "内容分析", "运营报告", "批量回复"]
    },
    "full": {
        "id": "full",
        "name": "全功能版",
        "description": "完整功能 + 创建/更新内容（需编辑权限）",
        "capabilities": ["browse", "read", "summarize", "statistics", "analysis", "reply_generation", "create", "update"],
        "required_permissions": ["read", "write"],
        "suitable_for": ["内容管理", "知识更新", "文档创建", "权限充足的管理员"]
    }
}


class TemplateSelector:
    """模板选择器"""

    def __init__(self):
        self.templates = TEMPLATE_INFO

    def list_templates(self):
        """列出所有可用模板"""
        return [
            {
                "id": info["id"],
                "name": info["name"],
                "description": info["description"],
                "capabilities": info["capabilities"],
                "suitable_for": info["suitable_for"]
            }
            for info in self.templates.values()
        ]

    def get_template(self, template_id):
        """获取指定模板信息"""
        return self.templates.get(template_id)

    def recommend(self, kb_info):
        """根据知识库信息推荐模板

        Args:
            kb_info: dict, 包含以下键:
                - has_write_permission: bool, 是否有写权限
                - size: str, 知识库规模 ("small", "medium", "large")
                - purpose: str, 用途 ("query", "operation", "management")

        Returns:
            str: 推荐的模板ID
        """
        has_write = kb_info.get("has_write_permission", False)
        size = kb_info.get("size", "medium")
        purpose = kb_info.get("purpose", "operation")

        if purpose == "query":
            return "basic"

        if not has_write:
            return "operation"

        if has_write:
            if size == "small":
                return "full"
            else:
                return "operation"

        return "operation"

    def validate_selection(self, template_id, kb_info):
        """验证选择是否合适

        Args:
            template_id: str, 模板ID
            kb_info: dict, 知识库信息

        Returns:
            dict: {"valid": bool, "reason": str}
        """
        if template_id not in self.templates:
            return {"valid": False, "reason": f"模板 '{template_id}' 不存在"}

        template = self.templates[template_id]
        required_perms = template.get("required_permissions", [])

        if "write" in required_perms:
            has_write = kb_info.get("has_write_permission", False)
            if not has_write:
                return {
                    "valid": False,
                    "reason": f"模板 '{template['name']}' 需要写权限，当前无写权限"
                }

        return {"valid": True, "reason": "选择合适"}


_selector = TemplateSelector()


def list_templates():
    """列出所有可用模板"""
    return _selector.list_templates()


def get_template_info(template_id):
    """获取指定模板信息"""
    return _selector.get_template(template_id)


def recommend_template(kb_info):
    """根据知识库信息推荐模板"""
    return _selector.recommend(kb_info)


def validate_selection(template_id, kb_info):
    """验证选择是否合适"""
    return _selector.validate_selection(template_id, kb_info)


if __name__ == "__main__":
    print("=== 模板列表 ===")
    for t in list_templates():
        print(f"- {t['id']}: {t['name']} - {t['description']}")

    print("\n=== 推荐示例 ===")
    print(f"无写权限: {recommend_template({'has_write_permission': False})}")
    print(f"有写权限+小库: {recommend_template({'has_write_permission': True, 'size': 'small'})}")
    print(f"有写权限+大库: {recommend_template({'has_write_permission': True, 'size': 'large'})}")

    print("\n=== 验证示例 ===")
    print(f"full模板+无写权限: {validate_selection('full', {'has_write_permission': False})}")
    print(f"full模板+有写权限: {validate_selection('full', {'has_write_permission': True})}")