import os
import shutil
from pathlib import Path
from typing import List, Optional


class Installer:
    """Skill 安装器"""

    @staticmethod
    def install(skill_dir: str, target_dir: Optional[str] = None) -> dict:
        """安装 Skill 到目标目录"""
        if target_dir is None:
            target_dir = os.getcwd()

        skill_path = Path(skill_dir)
        if not skill_path.exists():
            return {"success": False, "error": f"源目录不存在: {skill_dir}"}

        skill_name = skill_path.name
        target_path = Path(target_dir) / skill_name

        if target_path.exists():
            return {"success": False, "error": f"目标目录已存在: {target_path}"}

        try:
            shutil.copytree(skill_dir, target_path)
            return {"success": True, "installed": str(target_path)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @staticmethod
    def uninstall(skill_name: str, target_dir: Optional[str] = None) -> dict:
        """卸载 Skill"""
        if target_dir is None:
            target_dir = os.getcwd()

        target_path = Path(target_dir) / skill_name

        if not target_path.exists():
            return {"success": False, "error": f"Skill 不存在: {skill_name}"}

        try:
            shutil.rmtree(target_path)
            return {"success": True, "uninstalled": skill_name}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @staticmethod
    def list_installed(target_dir: Optional[str] = None) -> List[str]:
        """列出已安装的 Skill"""
        if target_dir is None:
            target_dir = os.getcwd()

        skills = []
        target_path = Path(target_dir)

        if not target_path.exists():
            return skills

        for item in target_path.iterdir():
            if item.is_dir() and (item / "SKILL.md").exists():
                skills.append(item.name)

        return skills


def install_skill(skill_dir: str, target_dir: Optional[str] = None) -> dict:
    """便捷函数：安装 Skill"""
    return Installer.install(skill_dir, target_dir)


def uninstall_skill(skill_name: str, target_dir: Optional[str] = None) -> dict:
    """便捷函数：卸载 Skill"""
    return Installer.uninstall(skill_name, target_dir)


def list_installed_skills(target_dir: Optional[str] = None) -> List[str]:
    """便捷函数：列出已安装的 Skill"""
    return Installer.list_installed(target_dir)


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("用法: python installer.py <install|uninstall|list> [参数]")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "install" and len(sys.argv) >= 3:
        result = install_skill(sys.argv[2])
    elif cmd == "uninstall" and len(sys.argv) >= 3:
        result = uninstall_skill(sys.argv[2])
    elif cmd == "list":
        result = list_installed_skills()
    else:
        print("参数错误")
        sys.exit(1)

    print(result)