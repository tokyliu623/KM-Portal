# -*- coding: utf-8 -*-
"""Skill Generator - Knowledge Base Operation Skill Generator"""

import os
import shutil
import json
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional


class SkillGenerator:
    """Knowledge Base Operation Skill Generator"""

    def __init__(self, builder_dir: str):
        self.builder_dir = Path(builder_dir)
        self.templates_dir = self.builder_dir / "scripts" / "templates"
        self.runtime_lib_dir = self.builder_dir / "runtime_lib"

    def generate(self, kb_info: Dict[str, Any], template: str, output_dir: Optional[str] = None,
                 token_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate a skill project from template.

        Args:
            kb_info: Knowledge base info dict with kb_name, kb_id
            template: Template name - 'basic', 'operation', or 'full'
            output_dir: Output directory (optional, defaults to {kb_name}-operation)
            token_id: Token ID for API authentication

        Returns:
            dict with success status and output path
        """
        kb_name = kb_info.get("kb_name", "unnamed")
        kb_id = kb_info.get("kb_id", 0)

        if output_dir:
            output_path = Path(output_dir)
        else:
            safe_name = kb_name.replace(" ", "-").replace("/", "-")
            output_path = Path.cwd() / f"{safe_name}-operation"

        try:
            output_path.mkdir(parents=True, exist_ok=True)

            self._copy_runtime_lib(output_path)

            self._create_unified_entry(output_path, kb_name, kb_id)

            self._render_template(template, kb_info, output_path)

            self._create_config(kb_info, output_path, token_id)

            self._create_skill_md(output_path, kb_name, kb_id)

            return {
                "success": True,
                "output_dir": str(output_path),
                "template": template,
                "kb_name": kb_name,
                "message": f"Skill项目已生成到: {output_path}"
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "template": template
            }

    def _copy_runtime_lib(self, output_dir: Path):
        """Copy runtime library files to scripts directory"""
        scripts_dir = output_dir / "scripts"
        scripts_dir.mkdir(exist_ok=True)

        runtime_files = [
            "kb_config.py",
            "kb_client.py",
            "kb_explorer.py",
            "kb_operation.py",
            "kb_document.py",
            "kb_analysis.py",
            "kb_distribute.py",
            "kb_prompts.py",
            "kb_errors.py",
            "kb_output.py",
        ]

        for filename in runtime_files:
            src = self.runtime_lib_dir / filename
            if src.exists():
                shutil.copy2(src, scripts_dir / filename)

        init_content = '''# -*- coding: utf-8 -*-
"""Knowledge Base Operation Runtime Library"""

from kb_config import save_token, get_token, check_config, get_env_url, get_setup_guide
from kb_client import KMClient, list_kbs, get_tree, get_content, create_content, update_content, test_connection
from kb_explorer import KBExplorer, explore_list_kbs, explore_show_tree, explore_browse, explore_find
from kb_document import KBDocument, doc_read, doc_read_batch, doc_create, doc_update
from kb_analysis import KBAnalysis, analyze_summarize, analyze_keywords, analyze_compare, analyze_batch
from kb_operation import KBOperation, op_health_check, op_stats, op_analyze_titles, op_report
from kb_distribute import KBDistribute, dist_generate_reply, dist_generate_draft, dist_publish, dist_clone

__all__ = [
    "save_token", "get_token", "check_config", "get_env_url", "get_setup_guide",
    "KMClient", "list_kbs", "get_tree", "get_content", "create_content", "update_content", "test_connection",
    "KBExplorer", "explore_list_kbs", "explore_show_tree", "explore_browse", "explore_find",
    "KBDocument", "doc_read", "doc_read_batch", "doc_create", "doc_update",
    "KBAnalysis", "analyze_summarize", "analyze_keywords", "analyze_compare", "analyze_batch",
    "KBOperation", "op_health_check", "op_stats", "op_analyze_titles", "op_report",
    "KBDistribute", "dist_generate_reply", "dist_generate_draft", "dist_publish", "dist_clone",
]
'''
        with open(scripts_dir / "__init__.py", "w", encoding="utf-8") as f:
            f.write(init_content)

    def _create_unified_entry(self, output_dir: Path, kb_name: str, kb_id: int):
        """Create unified __init__.py entry point"""
        entry_content = f'''# -*- coding: utf-8 -*-
"""Knowledge Base Operation Entry Point

KB_NAME: {kb_name}
KB_ID: {kb_id}
Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""

import sys
import os
from pathlib import Path

current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

from kb_explorer import KBExplorer, explore_list_kbs, explore_browse, explore_find
from kb_operation import KBOperation, op_health_check, op_stats, op_report
from kb_document import KBDocument, doc_read, doc_read_batch
from kb_analysis import KBAnalysis, analyze_summarize, analyze_keywords
from kb_distribute import KBDistribute, dist_generate_reply, dist_publish
from kb_config import save_token, get_token, check_config, get_env_url

KB_NAME = "{kb_name}"
KB_ID = {kb_id}


def run(action: str, **kwargs):
    """
    Unified entry point for all operations.

    Actions:
        browse: Browse knowledge base tree
        read: Read document content
        summarize: Summarize document
        stats: Get knowledge base statistics
        health: Health check
        report: Generate full report
        generate_reply: Generate reply draft
        publish: Publish document (requires confirmation)

    Args:
        action: Operation name
        **kwargs: Operation parameters

    Returns:
        Operation result dict
    """
    explorer = KBExplorer()
    operation = KBOperation()

    if action == "browse":
        return explorer.browse(kwargs.get("kb_id", KB_ID), depth=kwargs.get("depth", 3))

    elif action == "read":
        doc = KBDocument(KB_NAME)
        return doc.read(kwargs.get("content_id"))

    elif action == "summarize":
        analyzer = KBAnalysis()
        return analyzer.summarize(kwargs.get("content_id"))

    elif action == "stats":
        return operation.stats(kwargs.get("kb_id", KB_ID))

    elif action == "health":
        return operation.health_check(kwargs.get("kb_id", KB_ID))

    elif action == "report":
        return operation.report(kwargs.get("kb_id", KB_ID))

    elif action == "generate_reply":
        dist = KBDistribute(KB_NAME)
        return dist.generate_reply(kwargs.get("context"), kwargs.get("style", "standard"))

    elif action == "publish":
        dist = KBDistribute(KB_NAME)
        return dist.publish_draft(
            kwargs.get("kb_id", KB_ID),
            kwargs.get("title"),
            kwargs.get("content"),
            parent_id=kwargs.get("parent_id"),
            confirmed=kwargs.get("confirmed", False)
        )

    else:
        return {{
            "success": False,
            "error": f"Unknown action: {{action}}",
            "available_actions": ["browse", "read", "summarize", "stats", "health", "report", "generate_reply", "publish"]
        }}
'''
        with open(output_dir / "__init__.py", "w", encoding="utf-8") as f:
            f.write(entry_content)

    def _render_template(self, template: str, kb_info: Dict[str, Any], output_dir: Path):
        """Render template files"""
        template_dir = self.templates_dir / template
        if not template_dir.exists():
            raise ValueError(f"Template not found: {template}")

        kb_name = kb_info.get("kb_name", "unnamed")
        kb_id = kb_info.get("kb_id", 0)
        skill_name = f"{kb_name}运营助手"
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        variables = {
            "{skill_name}": skill_name,
            "{kb_name}": kb_name,
            "{kb_id}": str(kb_id),
            "{generated_at}": generated_at,
        }

        for template_file in template_dir.glob("*.template"):
            output_name = template_file.stem
            output_path = output_dir / output_name

            with open(template_file, "r", encoding="utf-8") as f:
                content = f.read()

            for placeholder, value in variables.items():
                content = content.replace(placeholder, value)

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)

    def _create_config(self, kb_info: Dict[str, Any], output_dir: Path, token_id: Optional[str] = None):
        """Create configuration file"""
        config_dir = output_dir / "config"
        config_dir.mkdir(exist_ok=True)

        config = {
            "kb_name": kb_info.get("kb_name", "知识库名称"),
            "kb_id": kb_info.get("kb_id", 0),
            "token_id": token_id or "",
        }

        config_path = config_dir / "user.json"
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

    def _create_skill_md(self, output_dir: Path, kb_name: str, kb_id: int):
        """Create SKILL.md with proper format (BOM + front matter)"""
        skill_name = self._generate_skill_name(kb_name)

        skill_md_content = f'''---
name: {skill_name}
description: {kb_name}知识库运营Skill。触发词：{kb_name}知识库、{kb_name}运营
---

# {kb_name}运营助手

> 知识库运营Skill（运营版）

## 基本信息

| 属性 | 值 |
|------|-----|
| **知识库ID** | {kb_id} |
| **知识库名称** | {kb_name} |

## 核心功能

| 功能 | 说明 |
|------|------|
| browse | 浏览知识库目录结构 |
| read | 读取文档内容 |
| stats | 获取知识库统计信息 |
| health | 健康检查 |
| analyze | 分析文档标题和内容 |

## 使用方式

```python
import sys
sys.path.insert(0, "scripts")

from kb_explorer import explore_browse
from kb_document import doc_read

# 浏览知识库
result = explore_browse({kb_id}, depth=3)

# 读取文档
result = doc_read(<文档ID>)
```

## 目录结构

```
├── SKILL.md              # Skill入口
├── README.md             # 使用说明
├── config/
│   └── user.json         # 用户配置
└── scripts/
    ├── __init__.py
    ├── kb_config.py      # 配置管理
    ├── kb_client.py      # API客户端
    ├── kb_explorer.py    # 浏览模块
    ├── kb_document.py    # 文档操作
    ├── kb_analysis.py    # 分析模块
    ├── kb_operation.py   # 运营模块
    └── kb_distribute.py  # 分发模块
```
'''

        skill_path = output_dir / "SKILL.md"
        with open(skill_path, "w", encoding="utf-8-sig") as f:
            f.write(skill_md_content)

    def _generate_skill_name(self, kb_name: str) -> str:
        """生成 Skill 名称（英文，无 ID）"""
        name_lower = kb_name.lower()
        name_slug = re.sub(r'[^a-z0-9]+', '-', name_lower)
        name_slug = name_slug.strip('-')

        if not name_slug:
            name_slug = "knowledge"

        return f"kb-{name_slug}-operation"


def generate_skill(kb_name: str, kb_id: int, template: str = "basic", output_dir: str = None,
                   token_id: str = None) -> Dict[str, Any]:
    """
    Convenience function to generate a skill.

    Args:
        kb_name: Knowledge base name
        kb_id: Knowledge base ID
        template: Template type - 'basic', 'operation', 'full'
        output_dir: Output directory (optional)
        token_id: Token ID for API authentication

    Returns:
        Generation result dict
    """
    builder_dir = Path(__file__).parent.parent
    generator = SkillGenerator(str(builder_dir))

    kb_info = {"kb_name": kb_name, "kb_id": kb_id}
    return generator.generate(kb_info, template, output_dir, token_id)


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print("Usage: python skill_generator.py <kb_name> <kb_id> [template] [output_dir] [token_id]")
        print("  template: basic | operation | full (default: basic)")
        print("  token_id: API token ID (optional)")
        sys.exit(1)

    kb_name = sys.argv[1]
    kb_id = int(sys.argv[2])
    template = sys.argv[3] if len(sys.argv) > 3 else "basic"
    output_dir = sys.argv[4] if len(sys.argv) > 4 else None
    token_id = sys.argv[5] if len(sys.argv) > 5 else None

    result = generate_skill(kb_name, kb_id, template, output_dir, token_id)
    print(json.dumps(result, ensure_ascii=False, indent=2))