# -*- coding: utf-8 -*-
"""
config_wizard.py - 配置向导模块

Token配置和知识库发现
"""

import sys
import os
from pathlib import Path
from typing import Dict, Any, List, Optional

current_dir = Path(__file__).parent
runtime_lib_dir = current_dir.parent / "runtime_lib"
if str(runtime_lib_dir) not in sys.path:
    sys.path.insert(0, str(runtime_lib_dir))

from kb_config import (
    check_config, save_token, get_tokens, get_token,
    get_env_url, get_setup_guide, ENV_URLS
)
from kb_client import KMClient, list_kbs


def get_tokens() -> list:
    """从 user.json 读取所有已注册的 tokens"""
    import json
    import os
    user_file = os.path.join(os.path.dirname(__file__), "user.json")
    if not os.path.exists(user_file):
        return []
    with open(user_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("tokens", [])


class ConfigWizard:
    """配置向导"""

    def __init__(self):
        self.tokens = get_tokens()

    def welcome(self) -> str:
        return """========================================
  知识库配置向导 (KM Config Wizard)
========================================

欢迎使用知识库配置向导！

本向导将帮助您：
1. 检查当前配置状态
2. 配置知识库访问Token
3. 验证连接是否正常
4. 探测可访问的知识库

支持的运行环境：
- dev: 开发环境 (wiki-dev.vmic.xyz)
- test: 测试环境 (wiki-test.vmic.xyz)
- pre: 预发环境 (wiki-pre.vmic.xyz)
- prd: 生产环境 (wiki.vivo.xyz)

输入 'q' 退出向导
=========================================="""

    def check_status(self) -> Dict[str, Any]:
        tokens = get_tokens()
        token_count = len(tokens)
        configured = token_count > 0

        connection_ok = False
        error = None
        guide = get_setup_guide()

        if configured:
            first_kb = list(tokens.keys())[0]
            token_info = tokens[first_kb]
            token = token_info.get("token")
            env = token_info.get("env", "prd")

            client = KMClient(token_id=token, km_api_url=get_env_url(env))
            result = client.test_connection()
            connection_ok = result.get("success", False)
            if not connection_ok:
                error = result.get("error", "连接失败")

        if configured and connection_ok:
            message = f"已配置 {token_count} 个知识库Token，连接正常"
        elif configured:
            message = f"已配置 {token_count} 个Token，但连接失败"
        else:
            message = "尚未配置任何Token"

        return {
            "success": configured and connection_ok,
            "configured": configured,
            "token_count": token_count,
            "connection_ok": connection_ok,
            "message": message,
            "error": error,
            "guide": guide
        }

    def configure(self, kb_name: str, token: str, env: str = "prd") -> Dict[str, Any]:
        """配置Token"""
        try:
            save_token(kb_name, token, env)

            client = KMClient(token_id=token, km_api_url=get_env_url(env))
            result = client.test_connection()

            if result.get("success"):
                return {
                    "success": True,
                    "message": f"配置成功：{kb_name} ({ENV_URLS.get(env, env)})"
                }
            else:
                return {
                    "success": False,
                    "message": f"Token已保存但连接失败: {result.get('error')}"
                }
        except ValueError as e:
            return {
                "success": False,
                "message": f"配置失败: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"配置失败: {str(e)}"
            }

    def discover_kbs(self) -> Dict[str, Any]:
        """发现可访问的知识库"""
        tokens = get_tokens()
        if not tokens:
            return {
                "success": False,
                "kbs": [],
                "count": 0,
                "message": "请先配置Token"
            }

        all_kbs = []
        for kb_name, token_info in tokens.items():
            token = token_info.get("token")
            env = token_info.get("env", "prd")

            client = KMClient(token_id=token, km_api_url=get_env_url(env))
            result = client.list_kbs()

            if result.get("success"):
                kbs = result.get("data", [])
                for kb in kbs:
                    all_kbs.append({
                        "kb_id": kb.get("kbId"),
                        "kb_name": kb.get("kbName"),
                        "permission": kb.get("effectivePermType"),
                        "access_blocked": kb.get("accessBlocked"),
                        "link": kb.get("link", "")
                    })

        return {
            "success": len(all_kbs) > 0,
            "kbs": all_kbs,
            "count": len(all_kbs),
            "message": f"发现 {len(all_kbs)} 个可访问知识库"
        }

    def select_kb(self, kbs: List[Dict], kb_id: int) -> Optional[Dict]:
        """选择指定知识库"""
        for kb in kbs:
            if kb.get("kb_id") == kb_id:
                return kb
        return None


def wizard_welcome() -> str:
    """获取欢迎信息"""
    wizard = ConfigWizard()
    return wizard.welcome()


def wizard_check() -> Dict[str, Any]:
    """检查配置状态"""
    wizard = ConfigWizard()
    return wizard.check_status()


def wizard_configure(kb_name: str, token: str, env: str = "prd") -> Dict[str, Any]:
    """配置Token"""
    wizard = ConfigWizard()
    return wizard.configure(kb_name, token, env)


def wizard_discover() -> Dict[str, Any]:
    """发现知识库"""
    wizard = ConfigWizard()
    return wizard.discover_kbs()


if __name__ == "__main__":
    print(wizard_welcome())
    print("\n检查配置状态...")
    status = wizard_check()
    print(f"\n状态: {status['message']}")
    if not status['configured']:
        print(f"\n{status['guide']}")