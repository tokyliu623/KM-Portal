# -*- coding: utf-8 -*-
"""
kb_probe.py - 知识库探测模块

探测知识库的权限和结构信息
"""

import sys
from pathlib import Path

current_dir = Path(__file__).parent
runtime_lib_dir = current_dir.parent / "runtime_lib"
if str(runtime_lib_dir) not in sys.path:
    sys.path.insert(0, str(runtime_lib_dir))

from kb_config import check_config, get_token, get_env_url, get_token_id
from kb_client import KMClient, list_kbs, get_tree


class KBProbe:
    """知识库探测器"""

    def __init__(self, kb_name: str = None):
        self.kb_name = kb_name
        self.token_id = get_token_id()
        self.client = KMClient(token_id=self.token_id)

    def probe_kb(self, kb_id: int) -> dict:
        """探测知识库读取权限和结构"""
        result = {
            "success": False,
            "kb_id": kb_id,
            "read_permission": False,
            "stats": {"total_items": 0, "folders": 0, "docs": 0},
            "error": None
        }

        tree_result = get_tree(kb_id, token_id=self.token_id)
        if not tree_result.get("success"):
            result["error"] = tree_result.get("error", "获取目录树失败")
            return result

        result["read_permission"] = True
        result["success"] = True

        tree_data = tree_result.get("data", [])
        self._count_items(tree_data, result["stats"])

        return result

    def probe_write_permission(self, kb_id: int) -> dict:
        """探测知识库写权限"""
        result = {
            "success": False,
            "kb_id": kb_id,
            "write_permission": False,
            "error": None
        }

        from kb_client import create_content
        test_title = "_kb_probe_test_"
        create_result = create_content(kb_id, test_title, "# probe", token_id=self.token_id, content_type="markdown", parent_id=None)

        if create_result.get("success"):
            result["write_permission"] = True
            result["success"] = True
            content_id = create_result.get("data", {}).get("contentId")
            if content_id:
                result["test_content_id"] = content_id
        else:
            error = create_result.get("error", "")
            if "权限" in str(error) or "403" in str(error):
                result["error"] = "无写权限"
            else:
                result["error"] = error

        return result

    def probe_all(self, kb_id: int) -> dict:
        """探测知识库完整信息"""
        result = {
            "success": False,
            "kb_id": kb_id,
            "read_permission": False,
            "write_permission": False,
            "stats": {"total_items": 0, "folders": 0, "docs": 0},
            "recommendation": None
        }

        read_result = self.probe_kb(kb_id)
        result["read_permission"] = read_result.get("read_permission", False)
        result["stats"] = read_result.get("stats", result["stats"])
        result["error"] = read_result.get("error")

        if result["read_permission"]:
            write_result = self.probe_write_permission(kb_id)
            result["write_permission"] = write_result.get("write_permission", False)
            if write_result.get("error") and not result["error"]:
                result["error"] = write_result.get("error")

        result["success"] = result["read_permission"]
        result["recommendation"] = self._get_recommendation(result)

        return result

    def _count_items(self, items: list, stats: dict):
        """统计目录树中的文件夹和文档数量"""
        for item in items:
            if item.get("hasChild"):
                stats["folders"] += 1
            else:
                stats["docs"] += 1
            stats["total_items"] += 1

    def _get_recommendation(self, result: dict) -> str:
        """根据探测结果推荐模板"""
        if not result.get("read_permission"):
            return "无法读取知识库，请检查权限配置"

        stats = result.get("stats", {})
        total = stats.get("total_items", 0)
        docs = stats.get("docs", 0)

        if not result.get("write_permission"):
            return "仅读权限，建议使用【基础版】进行内容查询"

        if total == 0:
            return "知识库为空，建议使用【全功能版】批量导入内容"
        elif docs < 10:
            return "内容较少，建议使用【全功能版】补充内容"
        elif docs < 50:
            return "内容规模适中，可使用【运营版】"
        else:
            return "内容规模较大，建议使用【运营版】并定期使用【知识分发】同步更新"


def probe_kb(kb_id: int, kb_name: str = None) -> dict:
    """便捷函数：探测知识库"""
    config = check_config()
    if not config.get("configured"):
        return {"success": False, "error": "Token未配置", "guide": config.get("guide")}

    probe = KBProbe(kb_name)
    return probe.probe_kb(kb_id)


def probe_write(kb_id: int, kb_name: str = None) -> dict:
    """便捷函数：探测写权限"""
    config = check_config()
    if not config.get("configured"):
        return {"success": False, "error": "Token未配置", "guide": config.get("guide")}

    probe = KBProbe(kb_name)
    return probe.probe_write_permission(kb_id)


def probe_all(kb_id: int, kb_name: str = None) -> dict:
    """便捷函数：完整探测"""
    config = check_config()
    if not config.get("configured"):
        return {"success": False, "error": "Token未配置", "guide": config.get("guide")}

    probe = KBProbe(kb_name)
    return probe.probe_all(kb_id)


def list_accessible_kbs() -> dict:
    """列出可访问的知识库"""
    config = check_config()
    if not config.get("configured"):
        return {"success": False, "error": "Token未配置", "guide": config.get("guide")}

    result = list_kbs()
    if not result.get("success"):
        return result

    kbs = result.get("data", [])
    return {
        "success": True,
        "kbs": [
            {
                "kb_id": kb.get("kbId"),
                "kb_name": kb.get("kbName"),
                "permission": kb.get("effectivePermType"),
                "access_blocked": kb.get("accessBlocked"),
                "link": kb.get("link")
            }
            for kb in kbs
        ],
        "count": len(kbs)
    }


if __name__ == "__main__":
    import json

    print("=== KB Probe 测试 ===\n")

    status = check_config()
    if not status.get("configured"):
        print("错误: Token未配置")
        print(status.get("guide", ""))
        sys.exit(1)

    print("Token已配置，开始探测...\n")

    result = list_accessible_kbs()
    if result.get("success"):
        print(f"发现 {result.get('count', 0)} 个可访问知识库：")
        for kb in result.get("kbs", []):
            print(f"  - {kb.get('kb_name')} (ID: {kb.get('kb_id')}, 权限: {kb.get('permission')})")
    else:
        print(f"探测失败: {result.get('error')}")