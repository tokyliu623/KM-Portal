# -*- coding: utf-8 -*-
"""
kb_config.py - 配置管理模块（KM_API模式）

配置存储位置：config/user.json
KM_API_URL：硬编码为 https://qds-test.vmic.xyz/api/km-api
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional

CONFIG_DIR = Path(__file__).parent.parent / "config"
USER_CONFIG_FILE = CONFIG_DIR / "user.json"

KM_API_URL = "https://qds-test.vmic.xyz/api/km-api"


def _ensure_config_dir():
    """确保配置目录存在"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_user_config() -> Dict[str, Any]:
    """加载用户配置"""
    _ensure_config_dir()
    if not USER_CONFIG_FILE.exists():
        return {}
    try:
        with open(USER_CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def get_token_id() -> Optional[str]:
    """从用户配置中读取 token_id"""
    config = load_user_config()
    return config.get("token_id")


def get_kb_id() -> Optional[int]:
    """从用户配置中读取 kb_id"""
    config = load_user_config()
    kb_id = config.get("kb_id")
    return int(kb_id) if kb_id else None


def get_kb_name() -> Optional[str]:
    """从用户配置中读取 kb_name"""
    config = load_user_config()
    return config.get("kb_name")


def save_user_config(config: Dict[str, Any]) -> bool:
    """保存用户配置"""
    _ensure_config_dir()
    try:
        with open(USER_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except IOError:
        return False


def check_config() -> Dict[str, Any]:
    """检查配置状态"""
    config = load_user_config()

    token_id = config.get("token_id")
    kb_id = config.get("kb_id")

    if not token_id or not kb_id:
        return {
            "configured": False,
            "guide": get_setup_guide(),
            "error": "Token 未配置"
        }

    return {
        "configured": True,
        "token_id": token_id,
        "kb_id": kb_id,
        "kb_name": config.get("kb_name")
    }


def get_km_api_url() -> str:
    """获取 KM_API URL（硬编码）"""
    return KM_API_URL


def get_setup_guide() -> str:
    """获取配置引导信息"""
    return """
=== 知识库运营助手配置 ===

本 Skill 已预配置，无需手动配置。

如需更换知识库，请重新生成 Skill。

如需帮助，请联系 Skill 创建者。
"""


def get_env_url(env: str) -> str:
    """获取环境 URL（保留兼容性）"""
    env_urls = {
        "dev": "https://wiki-dev.vmic.xyz",
        "test": "https://wiki-test.vmic.xyz",
        "pre": "https://wiki-pre.vmic.xyz",
        "prd": "https://wiki.vivo.xyz",
    }
    return env_urls.get(env, "https://wiki.vivo.xyz")


def get_wiki_url(env: str = "prd") -> str:
    """获取 Wiki URL"""
    return get_env_url(env)


def save_token(kb_name: str, token: str, env: str = "prd") -> bool:
    """保存 Token（兼容旧接口）"""
    config = load_user_config()
    if "tokens" not in config:
        config["tokens"] = {}
    config["tokens"][kb_name] = {
        "token": token,
        "env": env
    }
    return save_user_config(config)


def get_token(kb_name: Optional[str] = None) -> Optional[str]:
    """获取 Token（兼容旧接口）"""
    config = load_user_config()
    if kb_name and "tokens" in config:
        return config["tokens"].get(kb_name, {}).get("token")
    return None