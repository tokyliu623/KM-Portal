﻿# -*- coding: utf-8 -*-
"""
kb_client.py - HTTP API客户端（KM_API模式）

API格式：POST {km_api_url}/kb/{action}
认证方式：body中带 token_id, kb_id
KM_API_URL：硬编码为 https://qds-test.vmic.xyz/api/km-api
"""

import json
import time
import uuid
import requests
from typing import Dict, Any, List, Optional

import sys
from pathlib import Path
_parent_dir = str(Path(__file__).parent.parent)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)
try:
    from runtime_lib.kb_config import get_km_api_url
except ImportError:
    from kb_config import get_km_api_url

DEFAULT_TIMEOUT = 30


class KMClient:
    """KM HTTP API客户端（KM_API模式）"""

    def __init__(self, token_id: Optional[str] = None, kb_id: Optional[str] = None):
        self.km_api_url = get_km_api_url()
        if self.km_api_url and not self.km_api_url.endswith("/"):
            self.km_api_url += "/"
        self.token_id = token_id
        self.kb_id = kb_id

    def _get_headers(self) -> Dict[str, str]:
        """生成请求头"""
        return {
            "Content-Type": "application/json",
            "requestId": f"req-{int(time.time())}-{uuid.uuid4().hex[:8]}"
        }

    def _request(self, action: str, params: Optional[Dict] = None, method: str = "POST") -> Dict[str, Any]:
        """发送API请求"""
        if not self.km_api_url:
            return {
                "success": False,
                "error": "KM_API未配置",
                "code": "NOT_CONFIGURED"
            }

        url = f"{self.km_api_url}kb/{action}"
        start_time = time.time()

        body = {}
        if self.token_id:
            body["token_id"] = self.token_id
        if self.kb_id:
            body["kb_id"] = self.kb_id
        if params:
            body.update(params)

        try:
            headers = self._get_headers()

            if method == "GET":
                response = requests.get(url, headers=headers, json=body, timeout=DEFAULT_TIMEOUT)
            else:
                response = requests.post(url, headers=headers, json=body, timeout=DEFAULT_TIMEOUT)

            latency_ms = int((time.time() - start_time) * 1000)

            try:
                result = response.json()
            except json.JSONDecodeError:
                return {
                    "success": False,
                    "error": f"响应解析失败: {response.text[:200]}",
                    "request_id": None,
                    "latency_ms": latency_ms
                }

            if result.get("code") == 1:
                return {
                    "success": True,
                    "data": result.get("data"),
                    "msg": result.get("msg"),
                    "request_id": headers["requestId"],
                    "latency_ms": latency_ms
                }
            else:
                return {
                    "success": False,
                    "error": result.get("msg", "请求失败"),
                    "code": result.get("code"),
                    "request_id": headers["requestId"],
                    "latency_ms": latency_ms
                }

        except requests.Timeout:
            return {
                "success": False,
                "error": "请求超时",
                "code": "TIMEOUT",
                "latency_ms": int((time.time() - start_time) * 1000)
            }
        except requests.RequestException as e:
            return {
                "success": False,
                "error": str(e),
                "code": "REQUEST_ERROR",
                "latency_ms": int((time.time() - start_time) * 1000)
            }

    def list_kbs(self) -> Dict[str, Any]:
        """获取已授权知识库列表"""
        return self._request("info", {})

    def get_tree(self, kb_id: Optional[int] = None, parent_id: Optional[int] = None) -> Dict[str, Any]:
        """获取目录树"""
        data = {}
        if kb_id is not None:
            data["kb_id"] = kb_id
        if parent_id is not None:
            data["parent_id"] = parent_id
        return self._request("tree", data)

    def get_content(self, content_ids: List[int], content_type: str = "markdown") -> Dict[str, Any]:
        """获取文档内容"""
        return self._request("content", {
            "content_ids": content_ids,
            "content_type": content_type
        })

    def create_content(self, kb_id: int, title: str, content: str,
                       content_type: str = "markdown", parent_id: Optional[int] = None) -> Dict[str, Any]:
        """创建文档"""
        data = {
            "kb_id": kb_id,
            "title": title,
            "content_type": content_type,
            "content": content
        }
        if parent_id is not None:
            data["parent_id"] = parent_id
        return self._request("contents/create", data)

    def update_content(self, content_id: int, title: str, content: str,
                       content_type: str = "markdown") -> Dict[str, Any]:
        """更新文档"""
        return self._request("contents/update", {
            "content_id": content_id,
            "title": title,
            "content_type": content_type,
            "content": content
        })

    def test_connection(self) -> Dict[str, Any]:
        """测试连接"""
        result = self._request("info", {})
        if result.get("success"):
            return {
                "success": True,
                "message": "连接成功",
                "data": result.get("data")
            }
        return {
            "success": False,
            "message": "连接失败",
            "error": result.get("error")
        }


def _get_client(token_id: Optional[str] = None, kb_id: Optional[str] = None) -> KMClient:
    """获取客户端实例，自动从配置读取未提供的参数"""
    try:
        from .kb_config import get_token_id, get_kb_id
    except ImportError:
        from kb_config import get_token_id, get_kb_id
    final_token_id = token_id or get_token_id()
    final_kb_id = kb_id or get_kb_id()
    return KMClient(token_id=final_token_id, kb_id=final_kb_id)


def list_kbs(token_id: Optional[str] = None) -> Dict[str, Any]:
    """获取已授权知识库列表"""
    client = _get_client(token_id)
    return client.list_kbs()


def get_tree(kb_id: int, token_id: Optional[str] = None, parent_id: Optional[int] = None) -> Dict[str, Any]:
    """获取目录树"""
    client = _get_client(token_id)
    return client.get_tree(kb_id, parent_id)


def get_content(content_ids: List[int], token_id: Optional[str] = None, content_type: str = "markdown") -> Dict[str, Any]:
    """获取文档内容"""
    client = _get_client(token_id)
    return client.get_content(content_ids, content_type)


def create_content(kb_id: int, title: str, content: str,
                   token_id: Optional[str] = None, content_type: str = "markdown",
                   parent_id: Optional[int] = None) -> Dict[str, Any]:
    """创建文档"""
    client = _get_client(token_id)
    return client.create_content(kb_id, title, content, content_type, parent_id)


def update_content(content_id: int, title: str, content: str,
                   token_id: Optional[str] = None, content_type: str = "markdown") -> Dict[str, Any]:
    """更新文档"""
    client = _get_client(token_id)
    return client.update_content(content_id, title, content, content_type)


def test_connection(token_id: Optional[str] = None) -> Dict[str, Any]:
    """测试连接"""
    client = _get_client(token_id)
    return client.test_connection()


def search_kb_by_name(name: str, token_id: Optional[str] = None) -> Dict[str, Any]:
    """根据名称搜索知识库（模糊匹配）"""
    result = list_kbs(token_id)
    if not result.get("success"):
        return result

    name_lower = name.lower()
    for kb in result.get("data", []):
        kb_name = kb.get("kbName", "")
        if name_lower in kb_name.lower():
            return {
                "success": True,
                "kb": {
                    "kb_id": kb.get("kbId"),
                    "kb_name": kb_name,
                    "permission": kb.get("effectivePermType"),
                    "link": kb.get("link")
                }
            }

    return {
        "success": False,
        "error": f"未找到知识库：{name}"
    }