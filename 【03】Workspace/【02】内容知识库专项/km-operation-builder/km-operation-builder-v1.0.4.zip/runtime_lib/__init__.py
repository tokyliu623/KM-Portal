# -*- coding: utf-8 -*-
"""
runtime_lib - 知识库运营运行时公共库

提供知识库浏览、文档管理、内容分析、结构健康度分析和知识分发功能
"""

__version__ = "1.0.3"

from .kb_config import save_token, get_token, check_config, get_env_url, get_km_api_url, get_setup_guide
from .kb_client import KMClient, list_kbs, get_tree, get_content, create_content, update_content, test_connection
from .kb_explorer import KBExplorer, explore_list_kbs, explore_show_tree, explore_browse, explore_find
from .kb_document import KBDocument, doc_read, doc_read_batch, doc_create, doc_update
from .kb_analysis import KBAnalysis, analyze_summarize, analyze_keywords, analyze_compare, analyze_batch
from .kb_operation import KBOperation, op_health_check, op_stats, op_analyze_titles, op_report
from .kb_distribute import KBDistribute, dist_generate_reply, dist_generate_draft, dist_publish, dist_clone

__all__ = [
    "save_token", "get_token", "check_config", "get_env_url", "get_km_api_url", "get_setup_guide",
    "KMClient", "list_kbs", "get_tree", "get_content", "create_content", "update_content", "test_connection",
    "KBExplorer", "explore_list_kbs", "explore_show_tree", "explore_browse", "explore_find",
    "KBDocument", "doc_read", "doc_read_batch", "doc_create", "doc_update",
    "KBAnalysis", "analyze_summarize", "analyze_keywords", "analyze_compare", "analyze_batch",
    "KBOperation", "op_health_check", "op_stats", "op_analyze_titles", "op_report",
    "KBDistribute", "dist_generate_reply", "dist_generate_draft", "dist_publish", "dist_clone",
]