# -*- coding: utf-8 -*-
"""
kb_document.py - 文档管理场景

注意：v1不包含删除文档功能，KM API无此接口
"""

from typing import Dict, Any, List, Optional

from kb_client import get_content, create_content, update_content
from kb_config import check_config
from km_client import KMClient


class KBDocument:
    """文档管理场景"""

    def __init__(self, token_id: str = None, kb_id: str = None, km_api_url: str = None):
        from .kb_config import get_token_id, get_kb_id, get_km_api_url
        self.token_id = token_id or get_token_id()
        self.kb_id = kb_id or get_kb_id()
        self.km_api_url = km_api_url or get_km_api_url()
        self.client = KMClient(km_api_url=self.km_api_url, token_id=self.token_id)

    def check_config(self) -> Dict[str, Any]:
        """检查配置状态"""
        return check_config()

    def read(self, content_id: int, content_type: str = "markdown") -> Dict[str, Any]:
        """读取文档内容"""
        config = check_config()
        if not config.get("configured"):
            return {"success": False, "error": "请先配置accessToken", "guide": config.get("guide")}

        result = get_content([content_id], self.kb_name, content_type)
        if not result.get("success"):
            return {"success": False, "error": result.get("error")}

        data = result.get("data", {})
        contents = data.get("content", [])

        if not contents:
            return {"success": False, "error": "文档不存在"}

        doc = contents[0]
        return {
            "success": True,
            "doc": {
                "content_id": doc.get("contentId"),
                "title": doc.get("title"),
                "content": doc.get("content"),
                "kb_id": doc.get("kbId"),
                "kb_name": doc.get("kbName"),
                "link": doc.get("link")
            }
        }

    def read_batch(self, content_ids: List[int], content_type: str = "markdown") -> Dict[str, Any]:
        """批量读取文档"""
        result = get_content(content_ids, self.kb_name, content_type)
        if not result.get("success"):
            return {"success": False, "error": result.get("error")}

        data = result.get("data", {})
        contents = data.get("content", [])

        return {
            "success": True,
            "docs": [
                {
                    "content_id": doc.get("contentId"),
                    "title": doc.get("title"),
                    "content": doc.get("content"),
                    "kb_id": doc.get("kbId"),
                    "link": doc.get("link")
                }
                for doc in contents
            ],
            "count": len(contents)
        }

    def create(self, kb_id: int, title: str, content: str,
               content_type: str = "markdown", parent_id: Optional[int] = None) -> Dict[str, Any]:
        """创建文档"""
        config = check_config()
        if not config.get("configured"):
            return {"success": False, "error": "请先配置accessToken", "guide": config.get("guide")}

        if not title:
            return {"success": False, "error": "文档标题不能为空"}

        if not content:
            return {"success": False, "error": "文档内容不能为空"}

        result = create_content(kb_id, title, content, self.kb_name, content_type, parent_id)
        if not result.get("success"):
            return {"success": False, "error": result.get("error")}

        data = result.get("data", {})
        return {
            "success": True,
            "message": "文档创建成功",
            "doc": {
                "content_id": data.get("contentId"),
                "link": data.get("link")
            }
        }

    def update(self, content_id: int, content: str, title: Optional[str] = None,
               content_type: str = "markdown") -> Dict[str, Any]:
        """更新文档"""
        config = check_config()
        if not config.get("configured"):
            return {"success": False, "error": "请先配置accessToken", "guide": config.get("guide")}

        if not content:
            return {"success": False, "error": "文档内容不能为空"}

        result = update_content(content_id, title or "", content, self.kb_name, content_type)
        if not result.get("success"):
            return {"success": False, "error": result.get("error")}

        data = result.get("data", {})
        return {
            "success": True,
            "message": "文档更新成功",
            "doc": {
                "content_id": data.get("contentId"),
                "link": data.get("link")
            }
        }


def doc_read(content_id: int, kb_name: Optional[str] = None, content_type: str = "markdown") -> Dict[str, Any]:
    """便捷函数：读取文档"""
    doc = KBDocument(kb_name)
    return doc.read(content_id, content_type)


def doc_read_batch(content_ids: List[int], kb_name: Optional[str] = None, content_type: str = "markdown") -> Dict[str, Any]:
    """便捷函数：批量读取文档"""
    doc = KBDocument(kb_name)
    return doc.read_batch(content_ids, content_type)


def doc_create(kb_id: int, title: str, content: str, kb_name: Optional[str] = None,
               content_type: str = "markdown", parent_id: Optional[int] = None) -> Dict[str, Any]:
    """便捷函数：创建文档"""
    doc = KBDocument(kb_name)
    return doc.create(kb_id, title, content, content_type, parent_id)


def doc_update(content_id: int, content: str, kb_name: Optional[str] = None,
               title: Optional[str] = None, content_type: str = "markdown") -> Dict[str, Any]:
    """便捷函数：更新文档"""
    doc = KBDocument(kb_name)
    return doc.update(content_id, content, title, content_type)