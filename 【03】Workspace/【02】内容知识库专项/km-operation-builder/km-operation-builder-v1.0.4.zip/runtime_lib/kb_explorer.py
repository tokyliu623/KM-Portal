# -*- coding: utf-8 -*-
"""
kb_explorer.py - 知识库浏览场景

提供知识库目录浏览和内容检索功能
"""

from typing import Dict, Any, List, Optional

from kb_client import list_kbs, get_tree
from kb_config import check_config
from km_client import KMClient


class KBExplorer:
    """知识库浏览场景"""

    def __init__(self, token_id: str = None, kb_id: str = None, km_api_url: str = None):
        from .kb_config import get_token_id, get_kb_id, get_km_api_url
        self.token_id = token_id or get_token_id()
        self.kb_id = kb_id or get_kb_id()
        self.km_api_url = km_api_url or get_km_api_url()
        self.client = KMClient(km_api_url=self.km_api_url, token_id=self.token_id)

    def check_config(self) -> Dict[str, Any]:
        """检查配置状态"""
        return check_config()

    def list_kbs(self) -> Dict[str, Any]:
        """列出用户有权访问的知识库"""
        config = check_config()
        if not config.get("configured"):
            return {"success": False, "error": "请先配置accessToken", "guide": config.get("guide")}

        result = list_kbs(self.kb_name)
        if not result.get("success"):
            return {"success": False, "error": result.get("error")}

        kbs = result.get("data", [])
        return {
            "success": True,
            "kbs": [
                {
                    "kb_id": kb.get("kbId"),
                    "kb_name": kb.get("kbName"),
                    "permission": kb.get("effectivePermType"),
                    "access_blocked": kb.get("accessBlocked"),
                    "link": kb.get("link")
                }
                for kb in kbs
            ],
            "count": len(kbs)
        }

    def show_tree(self, kb_id: int, parent_id: Optional[int] = None) -> Dict[str, Any]:
        """显示知识库目录树"""
        result = get_tree(kb_id, self.kb_name, parent_id)
        if not result.get("success"):
            return {"success": False, "error": result.get("error")}

        items = result.get("data", [])
        return {
            "success": True,
            "tree": [
                {
                    "id": item.get("id"),
                    "title": item.get("title"),
                    "has_child": item.get("hasChild"),
                    "parent_id": item.get("parentId")
                }
                for item in items
            ],
            "count": len(items)
        }

    def browse(self, kb_id: int, depth: int = 2) -> Dict[str, Any]:
        """浏览知识库（支持多层级）"""
        def _browse_recursive(kb_id: int, parent_id: Optional[int], current_depth: int) -> List[Dict]:
            if current_depth > depth:
                return []

            result = get_tree(kb_id, self.kb_name, parent_id)
            if not result.get("success"):
                return []

            items = []
            for item in result.get("data", []):
                node = {
                    "id": item.get("id"),
                    "title": item.get("title"),
                    "has_child": item.get("hasChild")
                }
                if item.get("hasChild") and current_depth < depth:
                    node["children"] = _browse_recursive(kb_id, item.get("id"), current_depth + 1)
                items.append(node)
            return items

        return {
            "success": True,
            "tree": _browse_recursive(kb_id, None, 1)
        }

    def find_by_title(self, kb_id: int, keyword: str, depth: int = 3) -> Dict[str, Any]:
        """基于目录树标题查找页面"""
        result = self.browse(kb_id, depth)
        if not result.get("success"):
            return result

        matches = []

        def _search(nodes: List[Dict], path: str = ""):
            for node in nodes:
                current_path = f"{path}/{node.get('title', '')}" if path else node.get('title', '')
                if keyword.lower() in node.get("title", "").lower():
                    matches.append({
                        "id": node.get("id"),
                        "title": node.get("title"),
                        "path": current_path,
                        "has_child": node.get("has_child")
                    })
                if node.get("children"):
                    _search(node["children"], current_path)

        _search(result.get("tree", []))

        return {
            "success": True,
            "keyword": keyword,
            "matches": matches,
            "count": len(matches)
        }


def explore_list_kbs(kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：列出知识库"""
    explorer = KBExplorer(kb_name)
    return explorer.list_kbs()


def explore_show_tree(kb_id: int, kb_name: Optional[str] = None, parent_id: Optional[int] = None) -> Dict[str, Any]:
    """便捷函数：显示目录树"""
    explorer = KBExplorer(kb_name)
    return explorer.show_tree(kb_id, parent_id)


def explore_browse(kb_id: int, kb_name: Optional[str] = None, depth: int = 2) -> Dict[str, Any]:
    """便捷函数：浏览知识库"""
    explorer = KBExplorer(kb_name)
    return explorer.browse(kb_id, depth)


def explore_find(kb_id: int, keyword: str, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：查找页面"""
    explorer = KBExplorer(kb_name)
    return explorer.find_by_title(kb_id, keyword)