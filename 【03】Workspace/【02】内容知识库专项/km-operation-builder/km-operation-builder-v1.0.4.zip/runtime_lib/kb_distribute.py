# -*- coding: utf-8 -*-
"""
kb_distribute.py - 知识分发场景

注意：v1只做草稿生成，实际写入需用户确认
"""

from typing import Dict, Any, List, Optional

from kb_document import KBDocument
from kb_explorer import KBExplorer
from kb_config import check_config
from km_client import KMClient


class KBDistribute:
    """知识分发场景"""

    def __init__(self, token_id: str = None, kb_id: str = None, km_api_url: str = None):
        from .kb_config import get_token_id, get_kb_id, get_km_api_url
        self.token_id = token_id or get_token_id()
        self.kb_id = kb_id or get_kb_id()
        self.km_api_url = km_api_url or get_km_api_url()
        self.client = KMClient(km_api_url=self.km_api_url, token_id=self.token_id)
        self.doc = KBDocument(token_id, kb_id, km_api_url)
        self.explorer = KBExplorer(token_id, kb_id, km_api_url)

    def check_config(self) -> Dict[str, Any]:
        """检查配置状态"""
        return check_config()

    def generate_reply(self, context: str, style: str = "专业、礼貌、简洁") -> Dict[str, Any]:
        """生成回复（不写入知识库）

        注意：实际生成需要调用LLM，这里返回结构化信息供LLM使用
        """
        return {
            "success": True,
            "context": context,
            "style": style,
            "note": "请使用LLM基于context生成回复",
            "usage_tip": "可结合知识库内容生成更准确的回复"
        }

    def generate_doc_draft(self, topic: str, source_content: str = "") -> Dict[str, Any]:
        """生成知识库文档草稿（不写入知识库）

        注意：实际生成需要调用LLM，这里返回结构化信息供LLM使用
        """
        return {
            "success": True,
            "topic": topic,
            "source_content_length": len(source_content) if source_content else 0,
            "note": "请使用LLM基于topic生成文档草稿",
            "draft_template": f"""# {topic}

## 概述
[简要说明]

## 详细内容
[详细说明]

## 总结
[总结要点]
"""
        }

    def publish_draft(self, kb_id: int, title: str, content: str,
                      parent_id: Optional[int] = None, confirmed: bool = False) -> Dict[str, Any]:
        """发布文档草稿到知识库

        Args:
            kb_id: 知识库ID
            title: 文档标题
            content: 文档内容
            parent_id: 父目录ID
            confirmed: 是否确认发布（需显式确认）
        """
        if not confirmed:
            return {
                "success": True,
                "draft": {
                    "kb_id": kb_id,
                    "title": title,
                    "content_preview": content[:200] + "..." if len(content) > 200 else content,
                    "content_length": len(content)
                },
                "message": "草稿已生成，请设置confirmed=True确认发布",
                "requires_confirmation": True
            }

        return self.doc.create(kb_id, title, content, parent_id=parent_id)

    def clone_doc(self, source_content_id: int, target_kb_id: int,
                  target_parent_id: Optional[int] = None) -> Dict[str, Any]:
        """复制文档到目标知识库"""
        source = self.doc.read(source_content_id)
        if not source.get("success"):
            return source

        doc = source.get("doc", {})

        return self.doc.create(
            target_kb_id,
            doc.get("title", "复制文档"),
            doc.get("content", ""),
            parent_id=target_parent_id
        )


def dist_generate_reply(context: str, kb_name: Optional[str] = None, style: str = "专业、礼貌、简洁") -> Dict[str, Any]:
    """便捷函数：生成回复"""
    distribute = KBDistribute(kb_name)
    return distribute.generate_reply(context, style)


def dist_generate_draft(topic: str, kb_name: Optional[str] = None, source_content: str = "") -> Dict[str, Any]:
    """便捷函数：生成文档草稿"""
    distribute = KBDistribute(kb_name)
    return distribute.generate_doc_draft(topic, source_content)


def dist_publish(kb_id: int, title: str, content: str, kb_name: Optional[str] = None, confirmed: bool = False) -> Dict[str, Any]:
    """便捷函数：发布文档"""
    distribute = KBDistribute(kb_name)
    return distribute.publish_draft(kb_id, title, content, confirmed=confirmed)


def dist_clone(source_id: int, target_kb_id: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：复制文档"""
    distribute = KBDistribute(kb_name)
    return distribute.clone_doc(source_id, target_kb_id)