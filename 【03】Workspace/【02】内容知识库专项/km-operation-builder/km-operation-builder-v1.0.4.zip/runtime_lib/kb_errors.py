"""Error codes and error handling for knowledge base operations."""

ERROR_CODES = {
    "TOKEN_NOT_CONFIGURED": {
        "code": 1001,
        "message": "API Token未配置",
        "suggestion": "请在配置文件中设置有效的API Token"
    },
    "TOKEN_INVALID": {
        "code": 1002,
        "message": "API Token无效",
        "suggestion": "请检查Token是否正确，或重新获取新的Token"
    },
    "TOKEN_EXPIRED": {
        "code": 1003,
        "message": "API Token已过期",
        "suggestion": "请重新获取新的API Token"
    },
    "CONNECTION_FAILED": {
        "code": 2001,
        "message": "连接知识库服务失败",
        "suggestion": "请检查网络连接或知识库服务状态"
    },
    "KB_NOT_FOUND": {
        "code": 3001,
        "message": "知识库不存在",
        "suggestion": "请检查知识库ID是否正确"
    },
    "KB_PERMISSION_DENIED": {
        "code": 3002,
        "message": "没有访问该知识库的权限",
        "suggestion": "请联系知识库管理员申请权限"
    },
    "DOC_NOT_FOUND": {
        "code": 4001,
        "message": "文档不存在",
        "suggestion": "请检查文档ID是否正确"
    },
    "DOC_CREATE_FAILED": {
        "code": 4002,
        "message": "创建文档失败",
        "suggestion": "请检查文档内容是否符合要求"
    },
    "DOC_UPDATE_FAILED": {
        "code": 4003,
        "message": "更新文档失败",
        "suggestion": "请检查文档ID和内容是否正确"
    },
    "INVALID_PARAMS": {
        "code": 5001,
        "message": "参数无效",
        "suggestion": "请检查输入参数是否符合规范"
    }
}


def get_error(code_name: str) -> dict:
    """Get error details by error code name."""
    return ERROR_CODES.get(code_name, {
        "code": 9999,
        "message": "未知错误",
        "suggestion": "请联系技术支持"
    })