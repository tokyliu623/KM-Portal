"""Prompt templates for knowledge base operations."""

SUMMARIZE_PROMPT = """请总结以下文档的核心内容：

---
{content}
---

请按以下格式输出：
1. 标题：简洁概括文档主题
2. 摘要：100-200字概括核心要点
3. 关键点：3-5个核心观点
"""

KEYWORDS_PROMPT = """从以下文档中提取关键词：

---
{content}
---

请提取5-10个关键词，按相关性排序，格式为JSON数组：
["关键词1", "关键词2", ...]
"""

COMPARE_PROMPT = """请对比以下两份文档的异同：

【文档1】
{content1}

【文档2】
{content2}

请输出：
1. 相同点
2. 不同点
3. 互补建议
"""

REPLY_PROMPT = """基于以下知识库内容回答问题：

【问题】
{question}

【相关知识】
{context}

请生成准确、简洁的回答。如果知识库中没有相关信息，请明确说明。
"""

DRAFT_PROMPT = """请根据以下要求生成文档草稿：

【主题】
{topic}

【要求】
{requirements}

【参考内容】
{reference}

请生成结构清晰的文档草稿，包含标题、章节、内容。
"""