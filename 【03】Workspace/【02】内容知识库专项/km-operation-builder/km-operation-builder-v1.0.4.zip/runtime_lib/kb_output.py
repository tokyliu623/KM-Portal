"""Output formatting utilities for knowledge base operations."""

import json
from typing import Any, Dict, List, Optional, Tuple


def format_success(
    data: Any = None,
    message: str = "操作成功",
    metadata: Optional[Dict] = None
) -> Dict:
    """Format successful operation output."""
    result = {
        "success": True,
        "message": message
    }
    if data is not None:
        result["data"] = data
    if metadata:
        result["metadata"] = metadata
    return result


def format_error(
    error: str,
    code: int = 9999,
    suggestion: Optional[str] = None
) -> Dict:
    """Format error output."""
    result = {
        "success": False,
        "error": error,
        "code": code
    }
    if suggestion:
        result["suggestion"] = suggestion
    return result


def format_table(headers: List[str], rows: List[List[Any]]) -> str:
    """Format data as ASCII table."""
    if not rows:
        return "无数据"

    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    def format_row(cells):
        return "|" + "|".join(f" {str(c).ljust(w)} " for c, w in zip(cells, col_widths)) + "|"

    separator = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"

    lines = [separator, format_row(headers), separator]
    for row in rows:
        lines.append(format_row(row))
    lines.append(separator)

    return "\n".join(lines)


def format_tree(
    nodes: List[Dict],
    indent: int = 0,
    prefix: str = ""
) -> str:
    """Format data as tree structure."""
    lines = []
    for i, node in enumerate(nodes):
        is_last = i == len(nodes) - 1
        current_prefix = "└── " if is_last else "├── "
        lines.append(f"{prefix}{current_prefix}{node.get('name', node)}")

        if "children" in node and node["children"]:
            child_prefix = prefix + ("    " if is_last else "│   ")
            lines.append(format_tree(node["children"], indent + 1, child_prefix))

    return "\n".join(lines)


def format_json(data: Any, indent: int = 2) -> str:
    """Format data as JSON string."""
    return json.dumps(data, ensure_ascii=False, indent=indent)


def format_list(
    items: List[Dict],
    fields: Optional[List[str]] = None,
    headers: Optional[Dict[str, str]] = None
) -> str:
    """Format list data as table."""
    if not items:
        return "无数据"

    if fields is None:
        fields = list(items[0].keys()) if items else []

    if headers is None:
        headers = {f: f for f in fields}

    header_list = [headers.get(f, f) for f in fields]
    rows = [[item.get(f, "") for f in fields] for item in items]

    return format_table(header_list, rows)