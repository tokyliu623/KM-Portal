# -*- coding: utf-8 -*-
"""
kb_operation.py - 结构健康度分析场景

注意：v1只做结构健康度分析，不做活跃度分析（缺少访问数据）
"""

from typing import Dict, Any, List, Optional
from collections import Counter

from kb_explorer import KBExplorer
from kb_config import check_config
from km_client import KMClient


class KBOperation:
    """结构健康度分析场景"""

    def __init__(self, token_id: str = None, kb_id: str = None, km_api_url: str = None):
        from .kb_config import get_token_id, get_kb_id, get_km_api_url
        self.token_id = token_id or get_token_id()
        self.kb_id = kb_id or get_kb_id()
        self.km_api_url = km_api_url or get_km_api_url()
        self.client = KMClient(km_api_url=self.km_api_url, token_id=self.token_id)
        self.explorer = KBExplorer(token_id, kb_id, km_api_url)

    def check_config(self) -> Dict[str, Any]:
        """检查配置状态"""
        return check_config()

    def health_check(self, kb_id: int) -> Dict[str, Any]:
        """知识库结构健康度检查"""
        result = self.explorer.show_tree(kb_id)
        if not result.get("success"):
            return result

        items = result.get("tree", [])

        total_docs = len(items)
        docs_with_children = sum(1 for item in items if item.get("has_child"))
        leaf_docs = total_docs - docs_with_children

        health_score = 100
        if total_docs == 0:
            health_score = 0
        elif total_docs < 5:
            health_score = 50
        elif docs_with_children / total_docs > 0.8 if total_docs > 0 else False:
            health_score = 70

        return {
            "success": True,
            "kb_id": kb_id,
            "health_score": health_score,
            "stats": {
                "total_docs": total_docs,
                "folders": docs_with_children,
                "leaf_docs": leaf_docs,
                "folder_ratio": round(docs_with_children / total_docs, 2) if total_docs > 0 else 0
            },
            "recommendations": self._generate_recommendations(total_docs, docs_with_children, health_score)
        }

    def _generate_recommendations(self, total: int, folders: int, score: int) -> List[str]:
        """生成健康度建议"""
        recommendations = []

        if total == 0:
            recommendations.append("知识库为空，建议添加内容")
        elif total < 5:
            recommendations.append("文档数量较少，建议丰富内容")

        if folders / total > 0.8 if total > 0 else False:
            recommendations.append("目录结构偏多，建议合并")

        if score >= 80:
            recommendations.append("知识库结构健康")
        elif score >= 60:
            recommendations.append("知识库结构一般，建议优化")
        else:
            recommendations.append("知识库需要优化，建议补充内容和完善结构")

        return recommendations

    def stats(self, kb_id: int, depth: int = 3) -> Dict[str, Any]:
        """知识库结构统计"""
        result = self.explorer.browse(kb_id, depth)
        if not result.get("success"):
            return result

        tree = result.get("tree", [])

        stats = {
            "total": 0,
            "folders": 0,
            "docs": 0,
            "max_depth": 0,
            "depth_distribution": {},
            "empty_folders": []
        }

        def _count(node: Dict, depth: int = 1):
            stats["total"] += 1
            stats["max_depth"] = max(stats["max_depth"], depth)
            stats["depth_distribution"][depth] = stats["depth_distribution"].get(depth, 0) + 1

            if node.get("has_child"):
                stats["folders"] += 1
                children = node.get("children", [])
                if not children:
                    stats["empty_folders"].append({
                        "id": node.get("id"),
                        "title": node.get("title")
                    })
                for child in children:
                    _count(child, depth + 1)
            else:
                stats["docs"] += 1

        for item in tree:
            _count(item)

        return {
            "success": True,
            "kb_id": kb_id,
            "stats": stats
        }

    def analyze_titles(self, kb_id: int) -> Dict[str, Any]:
        """分析文档标题重复"""
        result = self.explorer.browse(kb_id, depth=5)
        if not result.get("success"):
            return result

        titles = []

        def _collect(node: Dict):
            if not node.get("has_child"):
                titles.append(node.get("title", ""))
            for child in node.get("children", []):
                _collect(child)

        for item in result.get("tree", []):
            _collect(item)

        title_counts = Counter(titles)
        duplicates = {title: count for title, count in title_counts.items() if count > 1}

        return {
            "success": True,
            "kb_id": kb_id,
            "total_titles": len(titles),
            "unique_titles": len(title_counts),
            "duplicate_titles": duplicates,
            "duplicate_count": len(duplicates)
        }

    def report(self, kb_id: int) -> Dict[str, Any]:
        """生成结构健康度报告"""
        health = self.health_check(kb_id)
        stats = self.stats(kb_id)
        titles = self.analyze_titles(kb_id)

        return {
            "success": True,
            "kb_id": kb_id,
            "report": {
                "health_score": health.get("health_score"),
                "total_docs": stats.get("stats", {}).get("total", 0),
                "folder_ratio": health.get("stats", {}).get("folder_ratio", 0),
                "duplicate_titles": titles.get("duplicate_count", 0),
                "recommendations": health.get("recommendations", [])
            }
        }


def op_health_check(kb_id: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：健康度检查"""
    operation = KBOperation(kb_name)
    return operation.health_check(kb_id)


def op_stats(kb_id: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：结构统计"""
    operation = KBOperation(kb_name)
    return operation.stats(kb_id)


def op_analyze_titles(kb_id: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：标题分析"""
    operation = KBOperation(kb_name)
    return operation.analyze_titles(kb_id)


def op_report(kb_id: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：生成报告"""
    operation = KBOperation(kb_name)
    return operation.report(kb_id)