# -*- coding: utf-8 -*-
"""
kb_analysis.py - 内容分析场景（依赖LLM）

注意：实际总结、关键词提取需要调用LLM，这里返回结构化信息供LLM使用
"""

from typing import Dict, Any, List, Optional

from kb_document import KBDocument
from kb_config import check_config
from km_client import KMClient


class KBAnalysis:
    """内容分析场景"""

    def __init__(self, token_id: str = None, kb_id: str = None, km_api_url: str = None):
        from .kb_config import get_token_id, get_kb_id, get_km_api_url
        self.token_id = token_id or get_token_id()
        self.kb_id = kb_id or get_kb_id()
        self.km_api_url = km_api_url or get_km_api_url()
        self.client = KMClient(km_api_url=self.km_api_url, token_id=self.token_id)
        self.doc = KBDocument(token_id, kb_id, km_api_url)

    def check_config(self) -> Dict[str, Any]:
        """检查配置状态"""
        return check_config()

    def summarize(self, content_id: int, max_length: int = 500) -> Dict[str, Any]:
        """总结文档内容

        注意：实际总结需要调用LLM，这里返回结构化信息供LLM使用
        """
        result = self.doc.read(content_id)
        if not result.get("success"):
            return result

        doc = result.get("doc", {})
        content = doc.get("content", "")

        return {
            "success": True,
            "doc_id": content_id,
            "title": doc.get("title"),
            "content_length": len(content),
            "content_preview": content[:500] if len(content) > 500 else content,
            "full_content": content,
            "link": doc.get("link"),
            "note": "请使用LLM基于full_content进行深度总结"
        }

    def extract_keywords(self, content_id: int, max_keywords: int = 10) -> Dict[str, Any]:
        """提取关键词

        注意：实际提取需要调用LLM，这里返回结构化信息供LLM使用
        """
        result = self.doc.read(content_id)
        if not result.get("success"):
            return result

        doc = result.get("doc", {})
        content = doc.get("content", "")

        return {
            "success": True,
            "doc_id": content_id,
            "title": doc.get("title"),
            "content_length": len(content),
            "full_content": content,
            "link": doc.get("link"),
            "note": f"请使用LLM基于full_content提取{max_keywords}个关键词"
        }

    def compare(self, content_id_1: int, content_id_2: int) -> Dict[str, Any]:
        """对比两个文档"""
        result1 = self.doc.read(content_id_1)
        result2 = self.doc.read(content_id_2)

        if not result1.get("success"):
            return result1
        if not result2.get("success"):
            return result2

        doc1 = result1.get("doc", {})
        doc2 = result2.get("doc", {})

        return {
            "success": True,
            "doc1": {
                "id": content_id_1,
                "title": doc1.get("title"),
                "content_length": len(doc1.get("content", "")),
                "content": doc1.get("content", ""),
                "link": doc1.get("link")
            },
            "doc2": {
                "id": content_id_2,
                "title": doc2.get("title"),
                "content_length": len(doc2.get("content", "")),
                "content": doc2.get("content", ""),
                "link": doc2.get("link")
            },
            "note": "请使用LLM对比两个文档的异同"
        }

    def batch_summarize(self, content_ids: List[int]) -> Dict[str, Any]:
        """批量总结文档"""
        results = []
        for cid in content_ids:
            result = self.summarize(cid)
            results.append({
                "content_id": cid,
                "result": result
            })

        return {
            "success": True,
            "total": len(content_ids),
            "results": results
        }


def analyze_summarize(content_id: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：总结文档"""
    analysis = KBAnalysis(kb_name)
    return analysis.summarize(content_id)


def analyze_keywords(content_id: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：提取关键词"""
    analysis = KBAnalysis(kb_name)
    return analysis.extract_keywords(content_id)


def analyze_compare(content_id_1: int, content_id_2: int, kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：对比文档"""
    analysis = KBAnalysis(kb_name)
    return analysis.compare(content_id_1, content_id_2)


def analyze_batch(content_ids: List[int], kb_name: Optional[str] = None) -> Dict[str, Any]:
    """便捷函数：批量分析"""
    analysis = KBAnalysis(kb_name)
    return analysis.batch_summarize(content_ids)