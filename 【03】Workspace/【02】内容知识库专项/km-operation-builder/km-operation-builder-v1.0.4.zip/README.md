# km-operation-builder

知识库运营Skill生成器，通过配置引导快速生成标准化的知识库运营Skill。

## 功能特性

- **配置引导**：交互式收集知识库配置信息
- **模板生成**：支持基础版/运营版/全功能版三种模板
- **标准化结构**：生成符合规范的Skill目录结构
- **即用型脚本**：预置浏览、读取、总结、统计、健康度、报告、分发等运营脚本

### 核心运营能力

| 能力 | 说明 |
|------|------|
| browse | 浏览知识库目录树 |
| read | 读取文档内容 |
| summarize | 总结文档要点 |
| stats | 知识库统计信息 |
| health | 健康度检查 |
| report | 生成完整运营报告 |
| generate_reply | 生成回复草稿 |
| publish | 发布文档 |

## 使用方式

### 触发方式

在BlueCode中输入以下触发词之一：
- "创建KB Skill"
- "知识库运营"
- "KB开发"
- "知识库模板"

### 交互流程

1. **提供知识库信息**
   - 知识库ID (kb_id)
   - 知识库名称 (kb_name)

2. **选择模板类型**
   - 基础版：浏览+读取
   - 运营版：基础版+统计+报告
   - 全功能版：运营版+总结+分发

3. **生成并交付**

## 模板类型说明

### 基础版
- 知识库浏览 (browse)
- 文档读取 (read)
- 适用场景：知识查询、文档检索

### 运营版
- 基础版全部能力
- 统计信息 (stats)
- 健康度检查 (health)
- 运营报告 (report)
- 适用场景：内容运营、状态监控

### 全功能版
- 运营版全部能力
- 文档总结 (summarize)
- 回复生成 (generate_reply)
- 文档发布 (publish)
- 适用场景：知识全生命周期管理

## 生成的Skill结构

```
km-{kb_name}/
├── SKILL.md              # Skill入口文档
├── README.md             # 使用说明
├── __init__.py           # 统一入口点
├── config/
│   └── user.example.json # 配置示例
└── scripts/
    ├── __init__.py       # 运行时库导出
    ├── kb_config.py      # 配置管理
    ├── kb_client.py      # API客户端
    ├── kb_explorer.py    # 浏览模块
    ├── kb_document.py    # 文档模块
    ├── kb_analysis.py    # 分析模块
    ├── kb_operation.py   # 运营模块
    ├── kb_distribute.py  # 分发模块
    ├── kb_prompts.py     # 提示词模板
    ├── kb_errors.py      # 错误处理
    └── kb_output.py      # 输出格式化
```

## 配置说明

生成的 `config/user.example.json` 包含：

```json
{
  "kb_name": "知识库名称",
  "kb_id": 12345,
  "token": "请在此处填入您的accessToken",
  "env": "prd"
}
```

### Token配置

Token存储位置：`~/.bluecode/skills/km_config/tokens.json`

首次使用需配置 accessToken，脚本会自动保存和管理。

## API配置

- **环境**: prd
- **API Base**: https://wiki.vivo.xyz/api/knowledge/v1/openapi/kb

## 注意事项

1. 生成的Skill需要配置正确的知识库ID和accessToken
2. 部分运营能力需要相应的权限
3. 发布操作需要二次确认